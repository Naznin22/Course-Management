package cse.web;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;

import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import java.sql.*;


/**
 * Servlet implementation class MyProject
 */
@WebServlet("/MyProject")
public class MyProject extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	 // JDBC driver name and database URL
	   static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
	   static final String DB_URL = "jdbc:mysql://localhost/MyProject";

	   //  Database credentials
	   static final String USER = "root";
	   static final String PASS = "root";
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MyProject() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
//		response.setContentType("text/html");
//		PrintWriter printWriter = response.getWriter();
//		printWriter.println("Hello World");
		
//		RequestDispatcher view=request.getRequestDispatcher("data.jsp");
//		view.forward(request,response);
		
		  HttpSession session=request.getSession();
		  response.setContentType("text/html");
		  PrintWriter out= response.getWriter();
		  out.println((int) session.getAttribute("id"));
		  out.println((String) session.getAttribute("name"));
		  out.println((String) session.getAttribute("role"));
		  
		  if(session.getAttribute("role")==null) {
       	   response.sendRedirect("http://localhost:8080/MyProject/");
          }else  if(session.getAttribute("role").equals("Student"))
            {
        	  try {
      			Statement stmt = (Statement) DBConnection.getStatement();
      			String sql = "SELECT * from courses where courses.id IN (SELECT course_id from students WHERE student_id=%d)";
      			sql= String.format(sql, (int)session.getAttribute("id"));
      			
      			ResultSet rs = stmt.executeQuery(sql);
      			request.setAttribute("courses", rs);
              
      		}catch(SQLException e) {
      			e.printStackTrace();
      		}
        	  
         	 RequestDispatcher view=request.getRequestDispatcher("Student.jsp");
       		view.forward(request,response);
          }
          else if(session.getAttribute("role").equals("Teacher"))
          {
        	  
        	  try {
        			Statement stmt = (Statement) DBConnection.getStatement();
        			String sql = "SELECT * from courses where teacher_id=%d";
        			sql= String.format(sql, (int)session.getAttribute("id"));
        			
        			ResultSet rs = stmt.executeQuery(sql);
        			request.setAttribute("courses", rs);
                
        		}catch(SQLException e) {
        			e.printStackTrace();
        		}
        	  
         	 RequestDispatcher view=request.getRequestDispatcher("Teacher.jsp");
       		view.forward(request,response);
          } else if(session.getAttribute("role").equals("Admin"))
          {
          	 RequestDispatcher view=request.getRequestDispatcher("Admin.jsp");
        		view.forward(request,response);
           }
		  
		  
		out.close();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		doGet(request, response);
		
		    response.setContentType("text/html");
	        PrintWriter out = response.getWriter();
	        
	        String username = request.getParameter("name");
	       
	        out.println(request.getParameter("name"));
	        out.print(", ");
	        /////////////////////
	        Connection conn = null;
	        Statement stmt = null;
	        try{
	           //STEP 2: Register JDBC driver
	           Class.forName("com.mysql.jdbc.Driver");

	           //STEP 3: Open a connection
	           System.out.println("Connecting to database...");
	           conn = (Connection) DriverManager.getConnection(DB_URL,USER,PASS);

	           //STEP 4: Execute a query
	           System.out.println("Creating statement...");
	           stmt = (Statement) conn.createStatement();
	
	           String sql;
	           //sql = "SELECT id, name, password, role FROM Users";
	           sql = "SELECT role FROM Users WHERE name=? and password=?";
	           PreparedStatement pst=conn.prepareStatement(sql);
	           pst.setString(1, username);
//	           pst.setString(1, name);
	        
	      /////////////////////////////////////////
//	           String rl = "SELECT role FROM Users WHERE name=request.getParameter(\"username\")";
//		        ResultSet sq = stmt.executeQuery(rl);
//		        while(sq.next()){
//		        if(sq.equals("Admin")) {
//		        	out.print("Admin! ");
//		        }
//		        else if(sq.equals("Teacher")) {
//		        	out.print("Teacher! ");
//		        }
//		        else {
//		        	out.print("Student! ");
//		        }
//		        }
		       /////////////////////////////////
		        
	           //STEP 5: Extract data from result set
	           //ResultSet rs = stmt.executeQuery(sql);
	           ResultSet rs = pst.executeQuery();
	           
	          if(rs.next()){
	        	   
	              //Retrieve by column name
	              int id  = rs.getInt("id");
	              String name = rs.getString("name");
	              String password = rs.getString("password");
	              String role = rs.getString("role");
	              
	              if(role.equals("Admin"))
	            	  out.print( "Admin_Role");
	            	  else if( role.equals("Teacher"))
	            	  out.print("Teacher");
	            	  else if(role.equals("Student"))
	            	  out.print( "Student");

	              //Display values
	              out.print("ID: " + id);
	              out.print(", Name: " + name);
	              out.print(", Password: " + password);
	              out.println(", Role: " + role);
	           }
	           //STEP 6: Clean-up environment
	           out.close();
	           rs.close();
	           stmt.close();
	           conn.close();
	        }catch(SQLException se){
	           //Handle errors for JDBC
	           se.printStackTrace();
	        }catch(Exception e){
	           //Handle errors for Class.forName
	           e.printStackTrace();
	        }finally{
	           //finally block used to close resources
	           try{
	              if(stmt!=null)
	                 stmt.close();
	           }catch(SQLException se2){
	           }// nothing we can do
	           try{
	              if(conn!=null)
	                 conn.close();
	           }catch(SQLException se){
	              se.printStackTrace();
	           }//end finally try
	        }//end try
	        System.out.println("Success!");
	        ////////////////////
	           
		
	}

}
