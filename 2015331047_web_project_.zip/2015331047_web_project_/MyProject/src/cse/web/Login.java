package cse.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mysql.jdbc.Statement;

/**
 * Servlet implementation class Login
 */
@WebServlet("/Login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Login() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
//		RequestDispatcher view=request.getRequestDispatcher("index.jsp");
//		view.forward(request,response);
		//doPost(request, response);
		response.sendRedirect("/MyProject"); 
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		 String name=request.getParameter("name");  
	     String password=request.getParameter("password"); 
	     
	     response.setContentType("text/html");
	        PrintWriter out = response.getWriter();
	     
	     try {
	     String sql = "SELECT * from users WHERE name='%s' AND password='%s'";
	     sql=String.format(sql, name, password);
	     
	     Statement stmt = (Statement) DBConnection.getStatement();
	     ResultSet rs = stmt.executeQuery(sql);
	     
	     if(rs.next()){
      	   
             //Retrieve by column name
             int id  = rs.getInt("id");
             name = rs.getString("name");
             password = rs.getString("password");
             String role = rs.getString("role");
           
             HttpSession session=request.getSession(); 
             session.setAttribute("id", id);
             session.setAttribute("name",name );
             session.setAttribute("role", role);
             
             response.sendRedirect("MyProject");
//             if(role.equals("Student"))
//             {
//            	 RequestDispatcher view=request.getRequestDispatcher("Student");
//            	 session.setAttribute("name",name );
//          		view.forward(request,response);
//             }
//             else if(role.equals("Teacher"))
//             {
//            	 RequestDispatcher view=request.getRequestDispatcher("Teacher");
//            	 session.setAttribute("name",name );
//          		view.forward(request,response);
//             }
             
   	        
             out.print(name);
             out.print(role);
             out.close();
            //response.sendRedirect("http://localhost:8080/MyProject/Home");
             //response.sendRedirect("/MyProject");
             
            
          }else {
        	  
        	  out.print("Sorry, username or password error!");  
              //request.getRequestDispatcher("login.jsp").include(request, response); 
  	        
          }
	     out.close();
	     
	     
	     }catch (SQLException e) {
	    	 e.printStackTrace();
	     }
	     
	     
	}

}
